# Clean Portfolio Starter

A minimal, fast, and stylish portfolio starter—no frameworks required. Drop it on any static host (Netlify, Vercel, Github Pages, Hostinger, etc.) and customize.

## Quick Start
1. Edit **index.html** → replace name, bio, and project cards.
2. Swap images in `assets/img/`. (SVGs included as light placeholders.)
3. Tweak colors and spacing in **assets/css/style.css**.
4. Connect the contact form to Formspree or Netlify Forms (optional).

## Structure
```
clean_portfolio_starter/
├─ index.html
├─ assets/
│  ├─ css/style.css
│  ├─ js/main.js
│  └─ img/
```

## Notes
- Fully responsive with a simple grid.
- Accessible color contrast, focus rings, and proper semantics.
- Zero build tools. Pure HTML/CSS/JS.
